LOQER ROOM - PROJECT HAWTHORNE
==============================

Release: 1.0.0
Date:    2026-02-16

HOW TO RUN
----------
1. Install LÖVE (Love2D) from https://love2d.org/
2. Double-click `hawthorne_release.love`

HOW TO CREATE AN EXE (Windows)
------------------------------
If you have `love.exe` installed:

1. Open PowerShell in this folder.
2. Run: 
   cmd /c "copy /b path\to\love.exe+hawthorne_release.love hawthorne_game.exe"

3. You can now run `hawthorne_game.exe` standalone!
